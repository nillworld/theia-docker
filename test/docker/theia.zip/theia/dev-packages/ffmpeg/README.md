# `ffmeg.node`

This is a [Node Native Addon](https://nodejs.org/docs/latest-v12.x/api/n-api.html) to dynamically link to Electron's `ffmpeg.dll` and fetch a list of included codecs.
