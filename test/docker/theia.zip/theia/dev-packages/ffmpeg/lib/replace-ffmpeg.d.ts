import * as ffmpeg from './ffmpeg';
export declare function replaceFfmpeg(options?: ffmpeg.FfmpegOptions): Promise<void>;
export declare function readElectronVersion(electronDist: string): Promise<string>;
//# sourceMappingURL=replace-ffmpeg.d.ts.map