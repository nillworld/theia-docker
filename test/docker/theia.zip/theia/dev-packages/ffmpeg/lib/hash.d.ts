/// <reference types="node" />
export declare function hashFile(filePath: string): Promise<Buffer>;
//# sourceMappingURL=hash.d.ts.map