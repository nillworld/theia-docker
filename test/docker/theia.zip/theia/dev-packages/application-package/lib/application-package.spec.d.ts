export {};
//# sourceMappingURL=application-package.spec.d.ts.map