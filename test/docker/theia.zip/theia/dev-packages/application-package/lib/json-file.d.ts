import writeJsonFile = require('write-json-file');
declare function readJsonFile(path: string): any;
export { writeJsonFile, readJsonFile };
//# sourceMappingURL=json-file.d.ts.map