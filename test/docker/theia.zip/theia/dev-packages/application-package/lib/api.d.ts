/**
 * The default supported API version the framework supports.
 * The version should be in the format `x.y.z`.
 */
export declare const DEFAULT_SUPPORTED_API_VERSION = "1.53.2";
//# sourceMappingURL=api.d.ts.map