export {};
//# sourceMappingURL=bin-theia-re-exports.d.ts.map