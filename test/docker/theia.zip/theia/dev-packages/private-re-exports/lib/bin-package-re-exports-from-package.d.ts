export {};
//# sourceMappingURL=bin-package-re-exports-from-package.d.ts.map