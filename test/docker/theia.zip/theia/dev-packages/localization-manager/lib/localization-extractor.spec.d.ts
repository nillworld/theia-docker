export {};
//# sourceMappingURL=localization-extractor.spec.d.ts.map