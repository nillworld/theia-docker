export {};
//# sourceMappingURL=localization-manager.spec.d.ts.map