export interface Localization {
    [key: string]: string | Localization;
}
export declare function sortLocalization(localization: Localization): Localization;
//# sourceMappingURL=common.d.ts.map