export default function assert({ suppress }: {
    suppress: boolean;
}): void;
//# sourceMappingURL=check-hoisting.d.ts.map