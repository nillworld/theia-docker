export {};
//# sourceMappingURL=theia.d.ts.map