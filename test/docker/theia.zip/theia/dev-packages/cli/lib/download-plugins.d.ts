declare global {
    interface Array<T> {
        flat(depth?: number): any;
    }
}
import { RequestInit, Response } from 'node-fetch';
/**
 * Available options when downloading.
 */
export interface DownloadPluginsOptions {
    /**
     * Determines if a plugin should be unpacked.
     * Defaults to `false`.
     */
    packed?: boolean;
    /**
     * Determines if failures while downloading plugins should be ignored.
     * Defaults to `false`.
     */
    ignoreErrors?: boolean;
    /**
     * The supported vscode API version.
     * Used to determine extension compatibility.
     */
    apiVersion?: string;
    /**
     * The open-vsx registry API url.
     */
    apiUrl?: string;
}
export default function downloadPlugins(options?: DownloadPluginsOptions): Promise<void>;
/**
 * Follow HTTP(S)_PROXY, ALL_PROXY and NO_PROXY environment variables.
 */
export declare function xfetch(url: string, options?: RequestInit): Promise<Response>;
//# sourceMappingURL=download-plugins.d.ts.map