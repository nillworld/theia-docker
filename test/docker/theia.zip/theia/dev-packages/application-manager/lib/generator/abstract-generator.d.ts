import { ApplicationPackage } from '@theia/application-package';
export interface GeneratorOptions {
    mode?: 'development' | 'production';
    splitFrontend?: boolean;
}
export declare abstract class AbstractGenerator {
    protected readonly pck: ApplicationPackage;
    protected options: GeneratorOptions;
    constructor(pck: ApplicationPackage, options?: GeneratorOptions);
    protected compileFrontendModuleImports(modules: Map<string, string>): string;
    protected compileBackendModuleImports(modules: Map<string, string>): string;
    protected compileElectronMainModuleImports(modules?: Map<string, string>): string;
    protected compileModuleImports(modules: Map<string, string>, fn: 'import' | 'require'): string;
    protected ifBrowser(value: string, defaultValue?: string): string;
    protected ifElectron(value: string, defaultValue?: string): string;
    protected write(path: string, content: string): Promise<void>;
    protected ifMonaco(value: () => string, defaultValue?: () => string): string;
    protected prettyStringify(object: object): string;
}
//# sourceMappingURL=abstract-generator.d.ts.map