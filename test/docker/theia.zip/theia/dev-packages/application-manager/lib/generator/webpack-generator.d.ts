import { AbstractGenerator } from './abstract-generator';
export declare class WebpackGenerator extends AbstractGenerator {
    generate(): Promise<void>;
    protected shouldGenerateUserWebpackConfig(): Promise<boolean>;
    get configPath(): string;
    get genConfigPath(): string;
    protected resolve(moduleName: string, path: string): string;
    protected compileWebpackConfig(): string;
    protected compileUserWebpackConfig(): string;
}
//# sourceMappingURL=webpack-generator.d.ts.map