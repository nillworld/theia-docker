import { AbstractGenerator, GeneratorOptions } from './abstract-generator';
export declare class FrontendGenerator extends AbstractGenerator {
    generate(options?: GeneratorOptions): Promise<void>;
    protected compileIndexPreload(frontendModules: Map<string, string>): string;
    protected compileIndexHtml(frontendModules: Map<string, string>): string;
    protected compileIndexHead(frontendModules: Map<string, string>): string;
    protected compileIndexJs(frontendModules: Map<string, string>): string;
    protected compileElectronMain(electronMainModules?: Map<string, string>): string;
}
//# sourceMappingURL=frontend-generator.d.ts.map