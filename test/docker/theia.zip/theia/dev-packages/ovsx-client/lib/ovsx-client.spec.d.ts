export {};
//# sourceMappingURL=ovsx-client.spec.d.ts.map