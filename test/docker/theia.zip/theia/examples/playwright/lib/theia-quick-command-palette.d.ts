import { ElementHandle } from '@playwright/test';
import { TheiaPageObject } from './theia-page-object';
export declare class TheiaQuickCommandPalette extends TheiaPageObject {
    selector: string;
    open(): Promise<void>;
    isOpen(): Promise<boolean>;
    trigger(...commandName: string[]): Promise<void>;
    protected triggerSingleCommand(commandName: string): Promise<void>;
    type(command: string): Promise<void>;
    protected selectedCommand(): Promise<ElementHandle<SVGElement | HTMLElement> | null>;
}
//# sourceMappingURL=theia-quick-command-palette.d.ts.map