import { TheiaDialog } from './theia-dialog';
export declare class TheiaAboutDialog extends TheiaDialog {
    isVisible(): Promise<boolean>;
}
//# sourceMappingURL=theia-about-dialog.d.ts.map