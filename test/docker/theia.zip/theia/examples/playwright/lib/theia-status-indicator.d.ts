import { ElementHandle } from '@playwright/test';
import { TheiaPageObject } from './theia-page-object';
export declare class TheiaStatusIndicator extends TheiaPageObject {
    protected elementSpanSelector: string;
    protected getElementHandle(): Promise<ElementHandle<SVGElement | HTMLElement> | null>;
    waitForVisible(): Promise<void>;
    protected getSelectorByTitle(title: string): string;
    getElementHandleByTitle(title: string): Promise<ElementHandle<SVGElement | HTMLElement> | null>;
    protected getSelectorByIcon(icon: string): string;
    getElementHandleByIcon(iconClass: string | string[], titleContain?: string): Promise<ElementHandle<SVGElement | HTMLElement> | null>;
    waitForVisibleByTitle(title: string, waitForDetached?: boolean): Promise<void>;
    waitForVisibleByIcon(icon: string, waitForDetached?: boolean): Promise<void>;
    isVisible(icon: string | string[], titleContain?: string): Promise<boolean>;
}
//# sourceMappingURL=theia-status-indicator.d.ts.map