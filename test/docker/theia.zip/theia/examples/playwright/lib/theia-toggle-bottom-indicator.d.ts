import { TheiaStatusIndicator } from './theia-status-indicator';
export declare class TheiaToggleBottomIndicator extends TheiaStatusIndicator {
    isVisible(): Promise<boolean>;
}
//# sourceMappingURL=theia-toggle-bottom-indicator.d.ts.map