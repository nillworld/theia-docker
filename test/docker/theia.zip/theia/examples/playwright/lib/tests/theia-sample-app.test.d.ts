export {};
//# sourceMappingURL=theia-sample-app.test.d.ts.map