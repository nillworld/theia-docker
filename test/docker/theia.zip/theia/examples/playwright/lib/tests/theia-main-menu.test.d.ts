export {};
//# sourceMappingURL=theia-main-menu.test.d.ts.map