export {};
//# sourceMappingURL=theia-text-editor.test.d.ts.map