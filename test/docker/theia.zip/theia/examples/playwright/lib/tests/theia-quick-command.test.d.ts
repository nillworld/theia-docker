export {};
//# sourceMappingURL=theia-quick-command.test.d.ts.map