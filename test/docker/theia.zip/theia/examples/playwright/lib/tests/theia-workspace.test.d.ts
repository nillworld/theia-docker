export {};
//# sourceMappingURL=theia-workspace.test.d.ts.map