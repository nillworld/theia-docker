export {};
//# sourceMappingURL=theia-app.test.d.ts.map