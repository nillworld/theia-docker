export {};
//# sourceMappingURL=theia-preference-view.test.d.ts.map