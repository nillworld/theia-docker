import test, { Page } from '@playwright/test';
export declare let page: Page;
export default test;
//# sourceMappingURL=theia-fixture.d.ts.map