export {};
//# sourceMappingURL=theia-status-bar.test.d.ts.map