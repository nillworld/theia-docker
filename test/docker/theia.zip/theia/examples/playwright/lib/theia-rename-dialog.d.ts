import { TheiaDialog } from './theia-dialog';
export declare class TheiaRenameDialog extends TheiaDialog {
    enterNewName(newName: string): Promise<void>;
    confirm(): Promise<void>;
}
//# sourceMappingURL=theia-rename-dialog.d.ts.map