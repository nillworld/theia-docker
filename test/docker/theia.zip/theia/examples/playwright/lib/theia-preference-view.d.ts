import { TheiaApp } from './theia-app';
import { TheiaView } from './theia-view';
export declare const PreferenceIds: {
    Explorer: {
        AutoReveal: string;
    };
    DiffEditor: {
        MaxComputationTime: string;
    };
};
export declare const DefaultPreferences: {
    Explorer: {
        AutoReveal: {
            Enabled: boolean;
        };
    };
    DiffEditor: {
        MaxComputationTime: string;
    };
};
export declare enum TheiaPreferenceScope {
    User = "User",
    Workspace = "Workspace"
}
export declare class TheiaPreferenceView extends TheiaView {
    customTimeout?: number;
    constructor(app: TheiaApp);
    open(preferenceScope?: TheiaPreferenceScope): Promise<TheiaView>;
    protected getScopeSelector(scope: TheiaPreferenceScope): string;
    openPreferenceScope(scope: TheiaPreferenceScope): Promise<void>;
    getBooleanPreferenceById(preferenceId: string): Promise<boolean>;
    getBooleanPreferenceByPath(sectionTitle: string, name: string): Promise<boolean>;
    setBooleanPreferenceById(preferenceId: string, value: boolean): Promise<void>;
    setBooleanPreferenceByPath(sectionTitle: string, name: string, value: boolean): Promise<void>;
    getStringPreferenceById(preferenceId: string): Promise<string>;
    getStringPreferenceByPath(sectionTitle: string, name: string): Promise<string>;
    setStringPreferenceById(preferenceId: string, value: string): Promise<void>;
    setStringPreferenceByPath(sectionTitle: string, name: string, value: string): Promise<void>;
    waitForModified(preferenceId: string): Promise<void>;
    resetStringPreferenceById(preferenceId: string): Promise<void>;
    resetStringPreferenceByPath(sectionTitle: string, name: string): Promise<void>;
    resetBooleanPreferenceById(preferenceId: string): Promise<void>;
    resetBooleanPreferenceByPath(sectionTitle: string, name: string): Promise<void>;
    private findPreferenceId;
    private findPreferenceEditorById;
    private getPreferenceSelector;
    private getPreferenceEditorSelector;
    private getPreferenceGutterSelector;
    private findPreferenceResetButton;
}
//# sourceMappingURL=theia-preference-view.d.ts.map