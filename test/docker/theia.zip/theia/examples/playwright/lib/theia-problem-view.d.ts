import { TheiaApp } from './theia-app';
import { TheiaView } from './theia-view';
export declare class TheiaProblemsView extends TheiaView {
    constructor(app: TheiaApp);
}
//# sourceMappingURL=theia-problem-view.d.ts.map