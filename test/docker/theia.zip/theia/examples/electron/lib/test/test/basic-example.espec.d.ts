export {};
//# sourceMappingURL=basic-example.espec.d.ts.map