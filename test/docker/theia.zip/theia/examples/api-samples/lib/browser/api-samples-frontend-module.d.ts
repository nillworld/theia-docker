import { ContainerModule } from '@theia/core/shared/inversify';
import '../../src/browser/style/branding.css';
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=api-samples-frontend-module.d.ts.map