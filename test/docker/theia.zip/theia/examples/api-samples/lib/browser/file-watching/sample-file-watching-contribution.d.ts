import { interfaces } from '@theia/core/shared/inversify';
export declare function bindSampleFileWatching(bind: interfaces.Bind): void;
//# sourceMappingURL=sample-file-watching-contribution.d.ts.map