import { DeflatedToolbarTree } from '@theia/toolbar/lib/browser/toolbar-interfaces';
export declare const SampleToolbarDefaultsOverride: () => DeflatedToolbarTree;
//# sourceMappingURL=sample-toolbar-defaults-override.d.ts.map