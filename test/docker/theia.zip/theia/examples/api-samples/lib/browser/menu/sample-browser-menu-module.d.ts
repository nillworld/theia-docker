import { ContainerModule } from '@theia/core/shared/inversify';
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=sample-browser-menu-module.d.ts.map