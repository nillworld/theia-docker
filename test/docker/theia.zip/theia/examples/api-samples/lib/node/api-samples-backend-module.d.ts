import { ContainerModule } from '@theia/core/shared/inversify';
declare const _default: ContainerModule;
export default _default;
//# sourceMappingURL=api-samples-backend-module.d.ts.map