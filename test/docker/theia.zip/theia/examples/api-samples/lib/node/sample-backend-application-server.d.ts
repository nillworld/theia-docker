/// <reference types="express" />
import { BackendApplicationServer } from '@theia/core/lib/node';
import express = require('@theia/core/shared/express');
export declare class SampleBackendApplicationServer implements BackendApplicationServer {
    configure(app: express.Application): void;
}
//# sourceMappingURL=sample-backend-application-server.d.ts.map